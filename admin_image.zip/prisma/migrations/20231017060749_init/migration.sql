-- AlterTable
ALTER TABLE `user` ADD COLUMN `is_varified` BOOLEAN NOT NULL DEFAULT false;
