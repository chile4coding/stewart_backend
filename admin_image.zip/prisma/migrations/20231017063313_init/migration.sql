/*
  Warnings:

  - You are about to alter the column `is_verified` on the `review` table. The data in that column could be lost. The data in that column will be cast from `TinyInt` to `VarChar(191)`.

*/
-- AlterTable
ALTER TABLE `review` MODIFY `date` VARCHAR(191) NOT NULL,
    MODIFY `is_verified` VARCHAR(191) NOT NULL;
