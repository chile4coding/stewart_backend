-- AlterTable
ALTER TABLE `review` MODIFY `rating` VARCHAR(191) NOT NULL;
