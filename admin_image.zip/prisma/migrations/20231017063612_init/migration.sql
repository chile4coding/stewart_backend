-- AlterTable
ALTER TABLE `review` MODIFY `rating` VARCHAR(191) NULL,
    MODIFY `date` VARCHAR(191) NULL,
    MODIFY `name` VARCHAR(191) NULL,
    MODIFY `is_verified` VARCHAR(191) NULL,
    MODIFY `comment` VARCHAR(191) NULL,
    MODIFY `avatar` VARCHAR(191) NULL;
