/*
  Warnings:

  - Made the column `rating` on table `review` required. This step will fail if there are existing NULL values in that column.
  - Made the column `date` on table `review` required. This step will fail if there are existing NULL values in that column.
  - Made the column `name` on table `review` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_verified` on table `review` required. This step will fail if there are existing NULL values in that column.
  - Made the column `comment` on table `review` required. This step will fail if there are existing NULL values in that column.
  - Made the column `avatar` on table `review` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE `review` MODIFY `rating` INTEGER NOT NULL,
    MODIFY `date` DATETIME(3) NOT NULL,
    MODIFY `name` VARCHAR(191) NOT NULL,
    MODIFY `is_verified` BOOLEAN NOT NULL DEFAULT false,
    MODIFY `comment` VARCHAR(191) NOT NULL,
    MODIFY `avatar` VARCHAR(191) NOT NULL;
