/*
  Warnings:

  - You are about to drop the column `is_verified` on the `review` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `review` DROP COLUMN `is_verified`;
