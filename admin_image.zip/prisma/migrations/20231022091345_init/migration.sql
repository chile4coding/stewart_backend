/*
  Warnings:

  - You are about to drop the column `discount` on the `size` table. All the data in the column will be lost.
  - You are about to drop the column `image` on the `size` table. All the data in the column will be lost.
  - You are about to drop the column `initial_color` on the `size` table. All the data in the column will be lost.
  - You are about to drop the column `price` on the `size` table. All the data in the column will be lost.
  - You are about to drop the column `subscriber_price` on the `size` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `color` ADD COLUMN `sales_price` DOUBLE NULL;

-- AlterTable
ALTER TABLE `product` ADD COLUMN `sales_price` DOUBLE NULL;

-- AlterTable
ALTER TABLE `size` DROP COLUMN `discount`,
    DROP COLUMN `image`,
    DROP COLUMN `initial_color`,
    DROP COLUMN `price`,
    DROP COLUMN `subscriber_price`;
