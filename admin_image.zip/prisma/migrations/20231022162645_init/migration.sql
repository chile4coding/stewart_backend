-- AlterTable
ALTER TABLE `product` ADD COLUMN `categoryName` VARCHAR(191) NULL;
